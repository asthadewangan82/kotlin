fun main(){
    val number :Int =22

    val maxIntegerValue: Int =Int.MAX_VALUE
    val minIntegerValue: Int =Int.MIN_VALUE
    println("Int minium value is : $minIntegerValue")
    println("Int maximum value is : $maxIntegerValue")

    val mymaxShortValue: Short =Short.MAX_VALUE
    val myminShortValue: Short =Short.MIN_VALUE
    println("Short minium value is : $myminShortValue")
    println("Short maximum value is : $mymaxShortValue")

    val mymaxbyteValue: Byte =Byte.MAX_VALUE
    val myminbyteValue: Byte =Byte.MIN_VALUE
    println("Byte minium value is : $myminbyteValue")
    println("Byte maximum value is : $mymaxbyteValue")

    val mymaxlongValue: Long =Long.MAX_VALUE
    val myminLongValue: Long =Long.MIN_VALUE
    println("Long minium value is : $myminLongValue")
    println("Long maximum value is : $mymaxlongValue")


}