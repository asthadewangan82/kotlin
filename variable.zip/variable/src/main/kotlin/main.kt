fun main(){
    var userName:String = "astha"
    var age: Int = 25


    println("hello $userName and you age is $age!! ")
}