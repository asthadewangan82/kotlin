enum class string {

}
